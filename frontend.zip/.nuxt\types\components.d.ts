
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T

interface _GlobalComponents {
  AdminDashboard: typeof import("../../app/components/AdminDashboard.vue")['default']
  AdminSidebar: typeof import("../../app/components/AdminSidebar.vue")['default']
  Appointments: typeof import("../../app/components/Appointments.vue")['default']
  AuditLogs: typeof import("../../app/components/AuditLogs.vue")['default']
  Availability: typeof import("../../app/components/Availability.vue")['default']
  BillingCommission: typeof import("../../app/components/BillingCommission.vue")['default']
  ClientManagement: typeof import("../../app/components/ClientManagement.vue")['default']
  DashboardHome: typeof import("../../app/components/DashboardHome.vue")['default']
  Earnings: typeof import("../../app/components/Earnings.vue")['default']
  LandingCTA: typeof import("../../app/components/LandingCTA.vue")['default']
  LandingFAQ: typeof import("../../app/components/LandingFAQ.vue")['default']
  LandingFeatures: typeof import("../../app/components/LandingFeatures.vue")['default']
  LandingForRNDs: typeof import("../../app/components/LandingForRNDs.vue")['default']
  LandingHero: typeof import("../../app/components/LandingHero.vue")['default']
  LandingHowItWorks: typeof import("../../app/components/LandingHowItWorks.vue")['default']
  LandingNavbar: typeof import("../../app/components/LandingNavbar.vue")['default']
  LandingTestimonials: typeof import("../../app/components/LandingTestimonials.vue")['default']
  LoginFlow: typeof import("../../app/components/LoginFlow.vue")['default']
  MealPlanning: typeof import("../../app/components/MealPlanning.vue")['default']
  Messages: typeof import("../../app/components/Messages.vue")['default']
  MyPatients: typeof import("../../app/components/MyPatients.vue")['default']
  NCPRecords: typeof import("../../app/components/NCPRecords.vue")['default']
  NavIcon: typeof import("../../app/components/NavIcon.vue")['default']
  NotificationDropdown: typeof import("../../app/components/NotificationDropdown.vue")['default']
  PlatformReports: typeof import("../../app/components/PlatformReports.vue")['default']
  ProfileDropdown: typeof import("../../app/components/ProfileDropdown.vue")['default']
  ProfileSettings: typeof import("../../app/components/ProfileSettings.vue")['default']
  RegisterFlow: typeof import("../../app/components/RegisterFlow.vue")['default']
  Resources: typeof import("../../app/components/Resources.vue")['default']
  Reviews: typeof import("../../app/components/Reviews.vue")['default']
  RndVerification: typeof import("../../app/components/RndVerification.vue")['default']
  SystemSettings: typeof import("../../app/components/SystemSettings.vue")['default']
  NuxtWelcome: typeof import("../../node_modules/nuxt/dist/app/components/welcome.vue")['default']
  NuxtLayout: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
  NuxtErrorBoundary: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
  ClientOnly: typeof import("../../node_modules/nuxt/dist/app/components/client-only")['default']
  DevOnly: typeof import("../../node_modules/nuxt/dist/app/components/dev-only")['default']
  ServerPlaceholder: typeof import("../../node_modules/nuxt/dist/app/components/server-placeholder")['default']
  NuxtLink: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-link")['default']
  NuxtLoadingIndicator: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
  NuxtTime: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
  NuxtRouteAnnouncer: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
  NuxtAnnouncer: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-announcer")['default']
  NuxtImg: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
  NuxtPicture: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
  NuxtPage: typeof import("../../node_modules/nuxt/dist/pages/runtime/page")['default']
  NoScript: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['NoScript']
  Link: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Link']
  Base: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Base']
  Title: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Title']
  Meta: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Meta']
  Style: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Style']
  Head: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Head']
  Html: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Html']
  Body: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Body']
  NuxtIsland: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-island")['default']
  LazyAdminDashboard: LazyComponent<typeof import("../../app/components/AdminDashboard.vue")['default']>
  LazyAdminSidebar: LazyComponent<typeof import("../../app/components/AdminSidebar.vue")['default']>
  LazyAppointments: LazyComponent<typeof import("../../app/components/Appointments.vue")['default']>
  LazyAuditLogs: LazyComponent<typeof import("../../app/components/AuditLogs.vue")['default']>
  LazyAvailability: LazyComponent<typeof import("../../app/components/Availability.vue")['default']>
  LazyBillingCommission: LazyComponent<typeof import("../../app/components/BillingCommission.vue")['default']>
  LazyClientManagement: LazyComponent<typeof import("../../app/components/ClientManagement.vue")['default']>
  LazyDashboardHome: LazyComponent<typeof import("../../app/components/DashboardHome.vue")['default']>
  LazyEarnings: LazyComponent<typeof import("../../app/components/Earnings.vue")['default']>
  LazyLandingCTA: LazyComponent<typeof import("../../app/components/LandingCTA.vue")['default']>
  LazyLandingFAQ: LazyComponent<typeof import("../../app/components/LandingFAQ.vue")['default']>
  LazyLandingFeatures: LazyComponent<typeof import("../../app/components/LandingFeatures.vue")['default']>
  LazyLandingForRNDs: LazyComponent<typeof import("../../app/components/LandingForRNDs.vue")['default']>
  LazyLandingHero: LazyComponent<typeof import("../../app/components/LandingHero.vue")['default']>
  LazyLandingHowItWorks: LazyComponent<typeof import("../../app/components/LandingHowItWorks.vue")['default']>
  LazyLandingNavbar: LazyComponent<typeof import("../../app/components/LandingNavbar.vue")['default']>
  LazyLandingTestimonials: LazyComponent<typeof import("../../app/components/LandingTestimonials.vue")['default']>
  LazyLoginFlow: LazyComponent<typeof import("../../app/components/LoginFlow.vue")['default']>
  LazyMealPlanning: LazyComponent<typeof import("../../app/components/MealPlanning.vue")['default']>
  LazyMessages: LazyComponent<typeof import("../../app/components/Messages.vue")['default']>
  LazyMyPatients: LazyComponent<typeof import("../../app/components/MyPatients.vue")['default']>
  LazyNCPRecords: LazyComponent<typeof import("../../app/components/NCPRecords.vue")['default']>
  LazyNavIcon: LazyComponent<typeof import("../../app/components/NavIcon.vue")['default']>
  LazyNotificationDropdown: LazyComponent<typeof import("../../app/components/NotificationDropdown.vue")['default']>
  LazyPlatformReports: LazyComponent<typeof import("../../app/components/PlatformReports.vue")['default']>
  LazyProfileDropdown: LazyComponent<typeof import("../../app/components/ProfileDropdown.vue")['default']>
  LazyProfileSettings: LazyComponent<typeof import("../../app/components/ProfileSettings.vue")['default']>
  LazyRegisterFlow: LazyComponent<typeof import("../../app/components/RegisterFlow.vue")['default']>
  LazyResources: LazyComponent<typeof import("../../app/components/Resources.vue")['default']>
  LazyReviews: LazyComponent<typeof import("../../app/components/Reviews.vue")['default']>
  LazyRndVerification: LazyComponent<typeof import("../../app/components/RndVerification.vue")['default']>
  LazySystemSettings: LazyComponent<typeof import("../../app/components/SystemSettings.vue")['default']>
  LazyNuxtWelcome: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
  LazyNuxtLayout: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
  LazyNuxtErrorBoundary: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
  LazyClientOnly: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/client-only")['default']>
  LazyDevOnly: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/dev-only")['default']>
  LazyServerPlaceholder: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
  LazyNuxtLink: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
  LazyNuxtLoadingIndicator: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
  LazyNuxtTime: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
  LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
  LazyNuxtAnnouncer: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-announcer")['default']>
  LazyNuxtImg: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
  LazyNuxtPicture: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
  LazyNuxtPage: LazyComponent<typeof import("../../node_modules/nuxt/dist/pages/runtime/page")['default']>
  LazyNoScript: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
  LazyLink: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Link']>
  LazyBase: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Base']>
  LazyTitle: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Title']>
  LazyMeta: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Meta']>
  LazyStyle: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Style']>
  LazyHead: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Head']>
  LazyHtml: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Html']>
  LazyBody: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Body']>
  LazyNuxtIsland: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-island")['default']>
}

declare module 'vue' {
  export interface GlobalComponents extends _GlobalComponents { }
}

export {}
