
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T


export const AdminDashboard: typeof import("../app/components/AdminDashboard.vue")['default']
export const AdminSidebar: typeof import("../app/components/AdminSidebar.vue")['default']
export const Appointments: typeof import("../app/components/Appointments.vue")['default']
export const AuditLogs: typeof import("../app/components/AuditLogs.vue")['default']
export const Availability: typeof import("../app/components/Availability.vue")['default']
export const BillingCommission: typeof import("../app/components/BillingCommission.vue")['default']
export const ClientManagement: typeof import("../app/components/ClientManagement.vue")['default']
export const DashboardHome: typeof import("../app/components/DashboardHome.vue")['default']
export const Earnings: typeof import("../app/components/Earnings.vue")['default']
export const LandingCTA: typeof import("../app/components/LandingCTA.vue")['default']
export const LandingFAQ: typeof import("../app/components/LandingFAQ.vue")['default']
export const LandingFeatures: typeof import("../app/components/LandingFeatures.vue")['default']
export const LandingForRNDs: typeof import("../app/components/LandingForRNDs.vue")['default']
export const LandingHero: typeof import("../app/components/LandingHero.vue")['default']
export const LandingHowItWorks: typeof import("../app/components/LandingHowItWorks.vue")['default']
export const LandingNavbar: typeof import("../app/components/LandingNavbar.vue")['default']
export const LandingTestimonials: typeof import("../app/components/LandingTestimonials.vue")['default']
export const LoginFlow: typeof import("../app/components/LoginFlow.vue")['default']
export const MealPlanning: typeof import("../app/components/MealPlanning.vue")['default']
export const Messages: typeof import("../app/components/Messages.vue")['default']
export const MyPatients: typeof import("../app/components/MyPatients.vue")['default']
export const NCPRecords: typeof import("../app/components/NCPRecords.vue")['default']
export const NavIcon: typeof import("../app/components/NavIcon.vue")['default']
export const NotificationDropdown: typeof import("../app/components/NotificationDropdown.vue")['default']
export const PlatformReports: typeof import("../app/components/PlatformReports.vue")['default']
export const ProfileDropdown: typeof import("../app/components/ProfileDropdown.vue")['default']
export const ProfileSettings: typeof import("../app/components/ProfileSettings.vue")['default']
export const RegisterFlow: typeof import("../app/components/RegisterFlow.vue")['default']
export const Resources: typeof import("../app/components/Resources.vue")['default']
export const Reviews: typeof import("../app/components/Reviews.vue")['default']
export const RndVerification: typeof import("../app/components/RndVerification.vue")['default']
export const SystemSettings: typeof import("../app/components/SystemSettings.vue")['default']
export const NuxtWelcome: typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']
export const NuxtLayout: typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
export const NuxtErrorBoundary: typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
export const ClientOnly: typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']
export const DevOnly: typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']
export const ServerPlaceholder: typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const NuxtLink: typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']
export const NuxtLoadingIndicator: typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
export const NuxtTime: typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
export const NuxtRouteAnnouncer: typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
export const NuxtAnnouncer: typeof import("../node_modules/nuxt/dist/app/components/nuxt-announcer")['default']
export const NuxtImg: typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
export const NuxtPicture: typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
export const NuxtPage: typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']
export const NoScript: typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']
export const Link: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']
export const Base: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']
export const Title: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']
export const Meta: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']
export const Style: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']
export const Head: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']
export const Html: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']
export const Body: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']
export const NuxtIsland: typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']
export const LazyAdminDashboard: LazyComponent<typeof import("../app/components/AdminDashboard.vue")['default']>
export const LazyAdminSidebar: LazyComponent<typeof import("../app/components/AdminSidebar.vue")['default']>
export const LazyAppointments: LazyComponent<typeof import("../app/components/Appointments.vue")['default']>
export const LazyAuditLogs: LazyComponent<typeof import("../app/components/AuditLogs.vue")['default']>
export const LazyAvailability: LazyComponent<typeof import("../app/components/Availability.vue")['default']>
export const LazyBillingCommission: LazyComponent<typeof import("../app/components/BillingCommission.vue")['default']>
export const LazyClientManagement: LazyComponent<typeof import("../app/components/ClientManagement.vue")['default']>
export const LazyDashboardHome: LazyComponent<typeof import("../app/components/DashboardHome.vue")['default']>
export const LazyEarnings: LazyComponent<typeof import("../app/components/Earnings.vue")['default']>
export const LazyLandingCTA: LazyComponent<typeof import("../app/components/LandingCTA.vue")['default']>
export const LazyLandingFAQ: LazyComponent<typeof import("../app/components/LandingFAQ.vue")['default']>
export const LazyLandingFeatures: LazyComponent<typeof import("../app/components/LandingFeatures.vue")['default']>
export const LazyLandingForRNDs: LazyComponent<typeof import("../app/components/LandingForRNDs.vue")['default']>
export const LazyLandingHero: LazyComponent<typeof import("../app/components/LandingHero.vue")['default']>
export const LazyLandingHowItWorks: LazyComponent<typeof import("../app/components/LandingHowItWorks.vue")['default']>
export const LazyLandingNavbar: LazyComponent<typeof import("../app/components/LandingNavbar.vue")['default']>
export const LazyLandingTestimonials: LazyComponent<typeof import("../app/components/LandingTestimonials.vue")['default']>
export const LazyLoginFlow: LazyComponent<typeof import("../app/components/LoginFlow.vue")['default']>
export const LazyMealPlanning: LazyComponent<typeof import("../app/components/MealPlanning.vue")['default']>
export const LazyMessages: LazyComponent<typeof import("../app/components/Messages.vue")['default']>
export const LazyMyPatients: LazyComponent<typeof import("../app/components/MyPatients.vue")['default']>
export const LazyNCPRecords: LazyComponent<typeof import("../app/components/NCPRecords.vue")['default']>
export const LazyNavIcon: LazyComponent<typeof import("../app/components/NavIcon.vue")['default']>
export const LazyNotificationDropdown: LazyComponent<typeof import("../app/components/NotificationDropdown.vue")['default']>
export const LazyPlatformReports: LazyComponent<typeof import("../app/components/PlatformReports.vue")['default']>
export const LazyProfileDropdown: LazyComponent<typeof import("../app/components/ProfileDropdown.vue")['default']>
export const LazyProfileSettings: LazyComponent<typeof import("../app/components/ProfileSettings.vue")['default']>
export const LazyRegisterFlow: LazyComponent<typeof import("../app/components/RegisterFlow.vue")['default']>
export const LazyResources: LazyComponent<typeof import("../app/components/Resources.vue")['default']>
export const LazyReviews: LazyComponent<typeof import("../app/components/Reviews.vue")['default']>
export const LazyRndVerification: LazyComponent<typeof import("../app/components/RndVerification.vue")['default']>
export const LazySystemSettings: LazyComponent<typeof import("../app/components/SystemSettings.vue")['default']>
export const LazyNuxtWelcome: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
export const LazyNuxtLayout: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
export const LazyNuxtErrorBoundary: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
export const LazyClientOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']>
export const LazyDevOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']>
export const LazyServerPlaceholder: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyNuxtLink: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
export const LazyNuxtLoadingIndicator: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
export const LazyNuxtTime: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
export const LazyNuxtAnnouncer: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-announcer")['default']>
export const LazyNuxtImg: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
export const LazyNuxtPicture: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
export const LazyNuxtPage: LazyComponent<typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']>
export const LazyNoScript: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
export const LazyLink: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']>
export const LazyBase: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']>
export const LazyTitle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']>
export const LazyMeta: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']>
export const LazyStyle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']>
export const LazyHead: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']>
export const LazyHtml: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']>
export const LazyBody: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']>
export const LazyNuxtIsland: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']>

export const componentNames: string[]
