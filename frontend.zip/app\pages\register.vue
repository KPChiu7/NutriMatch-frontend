<template>
  <RegisterFlow />
</template>