<template>
  <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
    <!-- Food Recall -->
    <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
      <div class="flex items-center gap-2 mb-4">
        <span class="text-xs font-bold uppercase tracking-wider text-gray-400">24-HOUR FOOD RECALL</span>
        <span class="ml-auto inline-flex items-center rounded-full bg-blue-50 px-2 py-0.5 text-xs font-medium text-blue-700">
          {{ mealLogs.length }} entries
        </span>
      </div>

      <form @submit.prevent="addMealLog" class="space-y-4">
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="mb-1 block text-xs font-semibold text-gray-600">Meal Slot</label>
            <select class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:border-[#d4a017] focus:outline-none focus:ring-1 focus:ring-[#d4a017]" v-model="newMeal.slot">
              <option>Breakfast</option>
              <option>AM Snack</option>
              <option>Lunch</option>
              <option>PM Snack</option>
              <option>Dinner</option>
            </select>
          </div>
          <div>
            <label class="mb-1 block text-xs font-semibold text-gray-600">Time</label>
            <input type="time" class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:border-[#d4a017] focus:outline-none focus:ring-1 focus:ring-[#d4a017]" v-model="newMeal.time" required />
          </div>
        </div>
        <div>
          <label class="mb-1 block text-xs font-semibold text-gray-600">What did you eat?</label>
          <textarea rows="3" class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:border-[#d4a017] focus:outline-none focus:ring-1 focus:ring-[#d4a017]" v-model="newMeal.details" placeholder="e.g. 1 cup brown rice..." required></textarea>
        </div>
        <button type="submit" class="w-full rounded-lg bg-[#1a3a1a] px-4 py-2 text-sm font-medium text-white hover:bg-[#0f2418] transition">
          + Save Food Log
        </button>
      </form>

      <div class="mt-4 space-y-2">
        <div v-for="meal in mealLogs.slice(0, 3)" :key="meal.id" class="flex items-center justify-between rounded-lg border border-gray-100 p-3">
          <div>
            <p class="text-sm font-medium text-gray-800">{{ meal.slot }}</p>
            <p class="text-xs text-gray-500">{{ meal.time }}</p>
          </div>
          <span class="text-xs text-gray-400">{{ meal.details }}</span>
        </div>
      </div>
    </div>

    <!-- Vitals Entry -->
    <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
      <div class="flex items-center gap-2 mb-4">
        <span class="text-xs font-bold uppercase tracking-wider text-gray-400">VITALS ENTRY</span>
      </div>

      <form @submit.prevent="saveVitals" class="space-y-4">
        <div>
          <label class="mb-1 block text-xs font-semibold text-gray-600">Weight (kg)</label>
          <input type="number" step="0.1" class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:border-[#d4a017] focus:outline-none focus:ring-1 focus:ring-[#d4a017]" v-model="vitalsForm.weight" required />
        </div>
        <div>
          <label class="mb-1 block text-xs font-semibold text-gray-600">Fasting Glucose (mg/dL)</label>
          <input type="number" class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:border-[#d4a017] focus:outline-none focus:ring-1 focus:ring-[#d4a017]" v-model="vitalsForm.glucose" required />
        </div>
        <div>
          <label class="mb-1 block text-xs font-semibold text-gray-600">Blood Pressure</label>
          <input type="text" class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:border-[#d4a017] focus:outline-none focus:ring-1 focus:ring-[#d4a017]" v-model="vitalsForm.bloodPressure" placeholder="120/80" />
        </div>
        <button type="submit" class="w-full rounded-lg bg-[#d4a017] px-4 py-2 text-sm font-medium text-white hover:bg-[#b88a12] transition">
          Save Vitals
        </button>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'

const mealLogs = ref([
  { id: 1, slot: 'Breakfast', time: '08:30', details: '2 eggs, 1 slice toast' },
  { id: 2, slot: 'Lunch', time: '12:30', details: 'Grilled chicken salad' },
  { id: 3, slot: 'Dinner', time: '19:00', details: 'Salmon with vegetables' }
])

const newMeal = reactive({ slot: 'Lunch', time: '12:30', details: '' })
const vitalsForm = reactive({ weight: 68.2, glucose: 112, bloodPressure: '' })

const addMealLog = () => {
  mealLogs.value.unshift({ 
    id: Date.now(), 
    slot: newMeal.slot, 
    time: newMeal.time, 
    details: newMeal.details 
  })
  newMeal.details = ''
  alert('Meal logged successfully! ✅')
}

const saveVitals = () => {
  alert('Vitals saved successfully! 📊')
}
</script>