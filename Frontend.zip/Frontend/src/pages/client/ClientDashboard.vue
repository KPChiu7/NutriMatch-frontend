<template>
  <div class="space-y-6">
    <!-- Stats Grid -->
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500">Current BMI</p>
            <p class="text-2xl font-bold text-gray-800">{{ stats.bmi }}</p>
          </div>
          <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-2xl">
            📊
          </div>
        </div>
        <span class="mt-2 inline-flex items-center rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-700">
          Normal Range
        </span>
      </div>

      <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500">Daily Target (TDEE)</p>
            <p class="text-2xl font-bold text-gray-800">{{ stats.tdee }} <span class="text-sm font-normal text-gray-500">kcal</span></p>
          </div>
          <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-orange-50 text-2xl">
            🔥
          </div>
        </div>
        <div class="mt-2 text-xs text-gray-500">P: {{ stats.protein }}g · C: {{ stats.carbs }}g · F: {{ stats.fat }}g</div>
      </div>

      <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500">NRS-2002 Score</p>
            <p class="text-2xl font-bold text-gray-800">2 <span class="text-sm font-normal text-gray-500">/ 7</span></p>
          </div>
          <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-yellow-50 text-2xl">
            📋
          </div>
        </div>
        <span class="mt-2 inline-flex items-center rounded-full bg-yellow-100 px-2 py-0.5 text-xs font-medium text-yellow-700">
          At Risk — Monitored
        </span>
      </div>

      <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500">Next Appointment</p>
            <p class="text-2xl font-bold text-gray-800">Jul 4</p>
          </div>
          <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-50 text-2xl">
            📅
          </div>
        </div>
        <div class="mt-2 text-xs text-gray-500">2:00 PM · Follow-up #3</div>
      </div>
    </div>

    <!-- Main Content -->
    <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
      <div class="lg:col-span-2 space-y-6">
        <WeightChart :weight="stats.weight" />
        
        <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
          <h3 class="text-sm font-semibold text-gray-800 mb-4">Clinical Alerts</h3>
          <div class="space-y-3">
            <div class="flex items-center justify-between rounded-lg bg-yellow-50 p-4 border-l-4 border-yellow-600">
              <div>
                <p class="font-semibold text-gray-800 text-sm">⚠️ Fasting blood glucose slightly elevated</p>
                <p class="text-xs text-gray-600">Latest: 112 mg/dL (target &lt;100)</p>
              </div>
              <router-link to="/client/logging" class="text-sm font-semibold text-[#1a3a1a] hover:underline">
                Log Vitals →
              </router-link>
            </div>
            <div class="flex items-center justify-between rounded-lg bg-green-50 p-4 border-l-4 border-green-600">
              <div>
                <p class="font-semibold text-gray-800 text-sm">✓ BMI within normal range</p>
                <p class="text-xs text-gray-600">{{ stats.bmi }} — consistently Normal for 3 months</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="space-y-6">
        <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
          <h3 class="text-sm font-semibold text-gray-800 mb-4">Your RND</h3>
          <div class="flex items-center gap-3 mb-4">
            <div class="flex h-10 w-10 items-center justify-center rounded-full bg-[#1a3a1a] font-bold text-white">IA</div>
            <div>
              <div class="font-semibold text-gray-800">RND Ivy Hope Alba</div>
              <div class="text-xs text-gray-500">Diabetes · Renal Nutrition</div>
              <div class="text-xs text-[#d4a017]">★ 4.9 (38 reviews)</div>
            </div>
          </div>
          <button class="w-full rounded-lg border border-[#1a3a1a] px-4 py-2 text-sm font-medium text-[#1a3a1a] hover:bg-[#1a3a1a] hover:text-white transition">
            💬 Send a Message
          </button>
        </div>

        <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
          <h3 class="text-sm font-semibold text-gray-800 mb-4">Quick Actions</h3>
          <div class="space-y-2">
            <router-link to="/client/tasks" class="flex items-center gap-3 rounded-lg border border-gray-200 px-4 py-2.5 text-sm hover:bg-gray-50 transition">
              <span>✅</span>
              <span>View Tasks</span>
            </router-link>
            <router-link to="/client/logging" class="flex items-center gap-3 rounded-lg border border-gray-200 px-4 py-2.5 text-sm hover:bg-gray-50 transition">
              <span>📝</span>
              <span>Log Food & Vitals</span>
            </router-link>
            <router-link to="/client/screening" class="flex items-center gap-3 rounded-lg border border-gray-200 px-4 py-2.5 text-sm hover:bg-gray-50 transition">
              <span>📊</span>
              <span>Screening History</span>
            </router-link>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import WeightChart from '../../components/WeightChart.vue'

const stats = ref({
  bmi: '22.4',
  tdee: '1,850',
  protein: '85',
  carbs: '220',
  fat: '65',
  weight: '68.2'
})
</script>