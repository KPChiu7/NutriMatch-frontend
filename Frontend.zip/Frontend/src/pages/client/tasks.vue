<template>
  <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
    <div class="flex items-center justify-between mb-4">
      <div class="flex items-center gap-3">
        <h3 class="text-sm font-semibold text-gray-800">My Tasks</h3>
        <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium"
          :class="pendingTasksCount ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'">
          {{ pendingTasksCount }} pending
        </span>
      </div>
    </div>

    <div class="space-y-3">
      <div v-for="task in tasks" :key="task.id" class="flex items-center gap-4 rounded-lg border border-gray-100 p-4 transition hover:bg-gray-50">
        <input type="checkbox" class="h-4 w-4 rounded border-gray-300 text-[#d4a017] focus:ring-[#d4a017]" v-model="task.completed" />
        <div class="flex-1">
          <div class="font-semibold text-gray-800" :class="{ 'text-gray-400 line-through': task.completed }">{{ task.title }}</div>
          <div class="text-xs text-gray-500">{{ task.freq }}</div>
        </div>
        <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium"
          :class="task.completed ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'">
          {{ task.completed ? '✅ Done' : '⏳ Pending' }}
        </span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'

const tasks = ref([
  { id: 1, title: 'Log daily food intake', freq: 'Daily', completed: false },
  { id: 2, title: 'Check blood glucose', freq: '3x daily', completed: false },
  { id: 3, title: 'Attend follow-up consultation', freq: 'Jul 20', completed: true },
  { id: 4, title: 'Review meal plan', freq: 'Weekly', completed: false }
])

const pendingTasksCount = computed(() => tasks.value.filter(t => !t.completed).length)
</script>