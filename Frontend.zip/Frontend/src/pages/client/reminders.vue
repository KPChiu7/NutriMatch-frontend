<template>
  <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
    <div class="flex items-center justify-between mb-4">
      <h3 class="text-sm font-semibold text-gray-800">My Reminders</h3>
      <button class="rounded-lg bg-[#1a3a1a] px-4 py-1.5 text-sm font-medium text-white hover:bg-[#0f2418] transition">
        + Add Reminder
      </button>
    </div>

    <div class="space-y-3">
      <div v-for="(rem, idx) in reminders" :key="idx" class="flex items-center gap-4 rounded-lg border border-gray-100 p-4 transition hover:bg-gray-50">
        <span class="text-2xl">⏰</span>
        <div class="flex-1">
          <div class="font-semibold text-gray-800">{{ rem.title }}</div>
          <div class="text-xs text-gray-500">{{ rem.time }}</div>
        </div>
        <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium"
          :class="{
            'bg-green-100 text-green-700': rem.status === 'Completed',
            'bg-yellow-100 text-yellow-700': rem.status === 'Pending'
          }">
          {{ rem.status }}
        </span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const reminders = ref([
  { title: 'Take morning medication', time: 'Daily, 8:00 AM', status: 'Pending' },
  { title: 'Log food intake', time: 'Daily, 9:00 PM', status: 'Pending' },
  { title: 'Doctor appointment', time: 'Jul 20, 2:00 PM', status: 'Completed' },
  { title: 'Check blood sugar', time: '3x daily', status: 'Pending' }
])
</script>