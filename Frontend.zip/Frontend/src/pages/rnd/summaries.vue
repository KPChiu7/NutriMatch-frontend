<template>
  <div class="space-y-6">
    <div v-for="summary in summaries" :key="summary.id" class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
      <div class="flex items-start justify-between">
        <div>
          <div class="font-bold text-[#1a3a1a]">{{ summary.title }}</div>
          <div class="text-xs text-gray-500">{{ summary.date }} · {{ summary.time }} · {{ summary.type }} · RND {{ summary.rnd }}</div>
        </div>
        <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium"
          :class="{
            'bg-green-100 text-green-700': summary.status === 'Completed',
            'bg-yellow-100 text-yellow-700': summary.status === 'Scheduled',
            'bg-gray-100 text-gray-700': summary.status === 'Cancelled'
          }">
          {{ summary.status }}
        </span>
      </div>
      <div class="mt-3 rounded-lg bg-gray-50 p-4">
        <p class="text-sm text-gray-700">
          <strong class="text-[#1a3a1a]">Key Notes:</strong> {{ summary.notes }}
        </p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const summaries = ref([
  {
    id: 1,
    title: 'Follow-up Consultation #2',
    date: 'June 15, 2026',
    time: '2:00 PM',
    type: 'Video',
    rnd: 'Ivy Hope Alba',
    status: 'Completed',
    notes: 'Fasting blood glucose reduced from 126 to 112 mg/dL. Food diary adherence improved. Lowered rice exchanges at dinner by 0.5 exchange.'
  },
  {
    id: 2,
    title: 'Follow-up Consultation #1',
    date: 'June 1, 2026',
    time: '11:00 AM',
    type: 'In-person',
    rnd: 'Ivy Hope Alba',
    status: 'Completed',
    notes: 'Initial assessment complete. Patient has good understanding of diabetes management. Set up monitoring schedule.'
  }
])
</script>