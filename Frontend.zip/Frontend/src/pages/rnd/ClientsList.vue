<template>
  <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
    <!-- Header -->
    <div class="flex items-center justify-between mb-4">
      <div class="flex items-center gap-3">
        <h3 class="text-sm font-semibold text-gray-800">My Clients</h3>
        <span class="inline-flex items-center rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-medium text-blue-700">
          {{ clients.length }} active
        </span>
      </div>
      <input 
        type="text" 
        class="rounded-lg border border-gray-200 px-3 py-1.5 text-sm placeholder:text-gray-400 focus:border-[#d4a017] focus:outline-none focus:ring-1 focus:ring-[#d4a017]"
        placeholder="Search clients..."
        v-model="searchQuery"
      />
    </div>

    <!-- Table -->
    <div class="overflow-x-auto">
      <table class="w-full border-collapse text-sm">
        <thead>
          <tr class="border-b border-gray-200">
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Client</th>
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Program</th>
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Week</th>
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Status</th>
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="client in filteredClients" :key="client.name" class="border-b border-gray-100 transition hover:bg-gray-50">
            <td class="px-3 py-3">
              <div class="flex items-center gap-2">
                <div class="flex h-8 w-8 items-center justify-center rounded-full bg-gray-200 text-xs font-semibold text-gray-600">
                  {{ client.initials }}
                </div>
                <span class="font-medium text-gray-800">{{ client.name }}</span>
              </div>
            </td>
            <td class="px-3 py-3 text-gray-600">{{ client.program }}</td>
            <td class="px-3 py-3 text-gray-600">Week {{ client.week }}</td>
            <td class="px-3 py-3">
              <span class="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium"
                :class="{
                  'bg-green-100 text-green-700': client.status === 'Active',
                  'bg-yellow-100 text-yellow-700': client.status === 'At Risk',
                  'bg-gray-100 text-gray-700': client.status === 'On Hold'
                }">
                {{ client.status }}
              </span>
            </td>
            <td class="px-3 py-3">
              <div class="flex items-center gap-2">
                <button class="rounded-lg bg-[#1a3a1a] px-3 py-1 text-xs font-medium text-white hover:bg-[#0f2418] transition">
                  View
                </button>
                <button class="rounded-lg border border-gray-200 px-3 py-1 text-xs font-medium text-gray-600 hover:bg-gray-50 transition">
                  Message
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { rndClientsList } from '../../mock/rndMockData'

const clients = ref(rndClientsList)
const searchQuery = ref('')

const filteredClients = computed(() => {
  if (!searchQuery.value) return clients.value
  return clients.value.filter(client => 
    client.name.toLowerCase().includes(searchQuery.value.toLowerCase())
  )
})
</script>