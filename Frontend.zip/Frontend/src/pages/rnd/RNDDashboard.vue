<template>
  <div class="space-y-6">
    <!-- Stats Grid -->
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500">Total Clients</p>
            <p class="text-2xl font-bold text-gray-800">24</p>
          </div>
          <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-2xl">
            🧑
          </div>
        </div>
        <div class="mt-2 flex items-center text-xs">
          <span class="text-green-600">↑ 2</span>
          <span class="ml-1 text-gray-500">new this month</span>
        </div>
      </div>

      <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500">Active Clients</p>
            <p class="text-2xl font-bold text-gray-800">18</p>
          </div>
          <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-green-50 text-2xl">
            ✅
          </div>
        </div>
        <div class="mt-2 flex items-center text-xs">
          <span class="text-green-600">75%</span>
          <span class="ml-1 text-gray-500">engagement rate</span>
        </div>
      </div>

      <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500">Pending Tasks</p>
            <p class="text-2xl font-bold text-gray-800">12</p>
          </div>
          <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-yellow-50 text-2xl">
            📋
          </div>
        </div>
        <div class="mt-2 flex items-center text-xs">
          <span class="text-red-600">5 overdue</span>
          <span class="ml-1 text-gray-500">need attention</span>
        </div>
      </div>

      <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500">Consultations</p>
            <p class="text-2xl font-bold text-gray-800">8</p>
          </div>
          <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-50 text-2xl">
            📅
          </div>
        </div>
        <div class="mt-2 flex items-center text-xs">
          <span class="text-blue-600">3 today</span>
          <span class="ml-1 text-gray-500">scheduled</span>
        </div>
      </div>
    </div>

    <!-- Main Content -->
    <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
      <div class="lg:col-span-2 bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-sm font-semibold text-gray-800">Recent Client Activity</h3>
          <router-link to="/rnd/clients" class="text-sm font-medium text-[#d4a017] hover:text-[#b88a12]">
            View All →
          </router-link>
        </div>
        <div class="space-y-4">
          <div v-for="client in recentClients" :key="client.name" class="flex items-center justify-between border-b border-gray-100 pb-3">
            <div class="flex items-center gap-3">
              <div class="flex h-10 w-10 items-center justify-center rounded-full bg-gray-200 font-semibold text-gray-600">
                {{ client.initials }}
              </div>
              <div>
                <p class="text-sm font-medium text-gray-800">{{ client.name }}</p>
                <p class="text-xs text-gray-500">{{ client.program }} · Week {{ client.week }}</p>
              </div>
            </div>
            <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium"
              :class="{
                'bg-green-100 text-green-700': client.status === 'Active',
                'bg-yellow-100 text-yellow-700': client.status === 'At Risk',
                'bg-gray-100 text-gray-700': client.status === 'On Hold'
              }">
              {{ client.status }}
            </span>
          </div>
        </div>
      </div>

      <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <h3 class="text-sm font-semibold text-gray-800 mb-4">Quick Actions</h3>
        <div class="space-y-3">
          <router-link to="/rnd/clients" class="flex w-full items-center gap-3 rounded-lg border border-gray-200 px-4 py-3 text-left transition hover:bg-gray-50">
            <span class="text-lg">👤</span>
            <span class="text-sm font-medium text-gray-700">View Clients</span>
          </router-link>
          <router-link to="/rnd/screening" class="flex w-full items-center gap-3 rounded-lg border border-gray-200 px-4 py-3 text-left transition hover:bg-gray-50">
            <span class="text-lg">📊</span>
            <span class="text-sm font-medium text-gray-700">Screening Records</span>
          </router-link>
          <router-link to="/rnd/tasks" class="flex w-full items-center gap-3 rounded-lg border border-gray-200 px-4 py-3 text-left transition hover:bg-gray-50">
            <span class="text-lg">✅</span>
            <span class="text-sm font-medium text-gray-700">Client Tasks</span>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const recentClients = ref([
  { name: 'Sarah Johnson', initials: 'SJ', program: 'Diabetes Management', week: 4, status: 'Active' },
  { name: 'Michael Chen', initials: 'MC', program: 'Renal Nutrition', week: 2, status: 'At Risk' },
  { name: 'Emily Davis', initials: 'ED', program: 'Weight Management', week: 6, status: 'Active' },
  { name: 'James Wilson', initials: 'JW', program: 'Diabetes Management', week: 1, status: 'On Hold' }
])
</script>