<template>
  <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
    <!-- Header -->
    <div class="flex items-center justify-between mb-4">
      <h3 class="text-sm font-semibold text-gray-800">Billing & Invoices</h3>
      <div class="flex items-center gap-2">
        <span class="inline-flex items-center rounded-full bg-green-50 px-2.5 py-0.5 text-xs font-medium text-green-700">
          💳 Total: $5,240.00
        </span>
        <button class="rounded-lg bg-[#1a3a1a] px-4 py-1.5 text-sm font-medium text-white hover:bg-[#0f2418] transition">
          + New Invoice
        </button>
      </div>
    </div>

    <!-- Table -->
    <div class="overflow-x-auto">
      <table class="w-full border-collapse text-sm">
        <thead>
          <tr class="border-b border-gray-200">
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Invoice</th>
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Client</th>
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Date</th>
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Amount</th>
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Status</th>
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Action</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="inv in invoices" :key="inv.id" class="border-b border-gray-100 transition hover:bg-gray-50">
            <td class="px-3 py-3 font-semibold text-[#1a3a1a]">{{ inv.id }}</td>
            <td class="px-3 py-3 text-gray-600">{{ inv.client }}</td>
            <td class="px-3 py-3 text-gray-600">{{ inv.date }}</td>
            <td class="px-3 py-3 font-bold text-gray-800">{{ inv.amount }}</td>
            <td class="px-3 py-3">
              <span class="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium"
                :class="{
                  'bg-green-100 text-green-700': inv.status === 'Paid',
                  'bg-yellow-100 text-yellow-700': inv.status === 'Pending',
                  'bg-red-100 text-red-700': inv.status === 'Overdue'
                }">
                {{ inv.status }}
              </span>
            </td>
            <td class="px-3 py-3">
              <button 
                @click="togglePay(inv)" 
                class="rounded-lg px-3 py-1 text-xs font-medium transition"
                :class="inv.paid ? 'border border-gray-200 text-gray-600 hover:bg-gray-50' : 'bg-[#d4a017] text-white hover:bg-[#b88a12]'"
              >
                {{ inv.paid ? '📄 Receipt' : '💰 Pay Now' }}
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const invoices = ref([
  { id: '#INV-001', client: 'Sarah Johnson', date: '2026-07-15', amount: '$250.00', status: 'Paid', paid: true },
  { id: '#INV-002', client: 'Michael Chen', date: '2026-07-10', amount: '$180.00', status: 'Pending', paid: false },
  { id: '#INV-003', client: 'Emily Davis', date: '2026-07-05', amount: '$320.00', status: 'Overdue', paid: false },
  { id: '#INV-004', client: 'James Wilson', date: '2026-06-28', amount: '$200.00', status: 'Paid', paid: true }
])

const togglePay = (inv) => {
  if (!inv.paid) {
    inv.paid = true
    inv.status = 'Paid'
  }
}
</script>