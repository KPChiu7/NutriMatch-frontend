<template>
  <div class="flex min-h-screen bg-gray-50 font-sans">
    <!-- Dark Panel -->
    <aside class="hidden flex-[0_0_44%] max-w-[560px] overflow-hidden bg-gradient-to-br from-[#1a3a1a] via-[#0f2418] to-[#0b1a12] px-12 py-14 text-white lg:flex">
      <div class="relative z-10 flex w-full flex-col justify-end">
        <div class="mb-4 font-serif text-[1.9rem] font-semibold tracking-tight">
          <span class="text-white">Nutri</span><span class="italic text-[#d4a017]">Match</span>
        </div>
        <p class="mb-8 max-w-[300px] font-serif text-[1.05rem] font-light leading-relaxed text-[#c2d6c2]">
          Nutrition care, matched to every step of the journey.
        </p>

        <svg class="mb-3 w-full" viewBox="0 0 420 220" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="pathGrad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stop-color="#d4a017" stop-opacity="0.9" />
              <stop offset="100%" stop-color="#ffd769" stop-opacity="0.95" />
            </linearGradient>
            <linearGradient id="pathFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#d4a017" stop-opacity="0.18" />
              <stop offset="100%" stop-color="#d4a017" stop-opacity="0" />
            </linearGradient>
          </defs>
          <path d="M8,170 C64,170 64,120 120,110 C176,100 176,58 232,50 C278,43 296,24 400,16 L400,210 L8,210 Z" fill="url(#pathFill)" />
          <path d="M8,170 C64,170 64,120 120,110 C176,100 176,58 232,50 C278,43 296,24 400,16" stroke="url(#pathGrad)" stroke-width="2.5" stroke-linecap="round" fill="none" />
          <circle cx="8" cy="170" r="4" fill="#ffd769" />
          <circle cx="120" cy="110" r="4" fill="#ffd769" />
          <circle cx="232" cy="50" r="4" fill="#ffd769" />
          <circle cx="400" cy="16" r="5" fill="#fff" stroke="#d4a017" stroke-width="2" />
        </svg>

        <ul class="flex gap-5 text-sm font-medium text-[#a3b8a3]">
          <li><span class="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-[#d4a017]"></span>Screening</li>
          <li><span class="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-[#d4a017]"></span>Guided care</li>
          <li><span class="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-[#d4a017]"></span>Steady progress</li>
        </ul>
      </div>
    </aside>

    <!-- Light Panel -->
    <main class="flex flex-1 items-center justify-center p-6 lg:p-12">
      <div class="w-full max-w-md">
        <!-- Mobile Brand -->
        <div class="mb-6 block text-center font-serif text-2xl font-semibold lg:hidden">
          <span class="text-[#1a3a1a]">Nutri</span><span class="italic text-[#d4a017]">Match</span>
        </div>

        <div class="mb-4 inline-block rounded-full bg-green-50 px-3 py-1 text-xs font-bold uppercase tracking-wide text-[#1a3a1a]">
          Demo mode · no password needed
        </div>

        <h1 class="font-serif text-3xl font-semibold text-[#0f2418]">Continue as</h1>
        <p class="mb-6 text-sm text-gray-500">Choose the role you'd like to preview.</p>

        <div class="space-y-2.5">
          <button
            v-for="option in roleOptions"
            :key="option.role"
            type="button"
            class="flex w-full items-center gap-4 rounded-xl border border-gray-200 bg-white px-4 py-3.5 text-left transition hover:border-[#1a3a1a] hover:-translate-y-0.5 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-[#d4a017] focus:ring-offset-2"
            @click="selectRole(option.role)"
          >
            <div class="flex h-10 w-10 items-center justify-center rounded-lg text-lg"
              :class="{
                'bg-green-50': option.role === 'client',
                'bg-yellow-50': option.role === 'rnd',
                'bg-gray-100': option.role === 'admin'
              }">
              {{ option.icon }}
            </div>
            <div class="flex-1">
              <div class="font-bold text-[#0f2418]">{{ option.label }}</div>
              <div class="text-xs text-gray-500">{{ option.description }}</div>
            </div>
            <span class="text-gray-300 transition group-hover:text-[#d4a017] group-hover:translate-x-0.5">→</span>
          </button>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

const roleOptions = [
  { role: 'client', icon: '🧑', label: 'Client', description: 'View your nutrition program' },
  { role: 'rnd', icon: '🩺', label: 'RND', description: 'Manage your assigned clients' },
  { role: 'admin', icon: '🗂️', label: 'Admin', description: 'Manage users & billing' }
]

function selectRole(role) {
  const routes = {
    client: '/client/dashboard',
    rnd: '/rnd/dashboard',
    admin: '/admin/dashboard'
  }
  router.push(routes[role])
}
</script>