<template>
  <div class="space-y-6">
    <!-- Metrics -->
    <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
      <div class="mb-4 flex items-center gap-2">
        <span class="text-xs font-bold uppercase tracking-wider text-gray-400">PRE-CONSULTATION SCREENING RECORD</span>
        <span class="ml-auto inline-flex items-center rounded-full bg-green-50 px-2 py-0.5 text-xs font-medium text-green-700">
          {{ stats.bmi }} BMI
        </span>
      </div>

      <div class="grid grid-cols-3 gap-4">
        <div class="text-center rounded-lg bg-gray-50 p-4">
          <div class="text-2xl font-bold text-gray-800">{{ stats.bmi }}</div>
          <div class="text-xs text-gray-500">BMI</div>
          <span class="inline-flex items-center rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-700 mt-1">
            Normal
          </span>
        </div>
        <div class="text-center rounded-lg bg-gray-50 p-4">
          <div class="text-2xl font-bold text-gray-800">1,312</div>
          <div class="text-xs text-gray-500">BMR (kcal)</div>
        </div>
        <div class="text-center rounded-lg bg-gray-50 p-4">
          <div class="text-2xl font-bold text-gray-800">{{ stats.tdee }}</div>
          <div class="text-xs text-gray-500">TDEE (kcal)</div>
        </div>
      </div>
    </div>

    <!-- Screening History -->
    <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
      <h3 class="text-sm font-semibold text-gray-800 mb-4">Screening History</h3>
      <div class="overflow-x-auto">
        <table class="w-full border-collapse text-sm">
          <thead>
            <tr class="border-b border-gray-200">
              <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Date</th>
              <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Weight</th>
              <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Height</th>
              <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">BMI</th>
              <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">NRS Score</th>
              <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">TDEE</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(history, index) in historyList" :key="index" class="border-b border-gray-100 transition hover:bg-gray-50">
              <td class="px-3 py-3 text-gray-600">{{ history.date }}</td>
              <td class="px-3 py-3 text-gray-600">{{ history.weight }}</td>
              <td class="px-3 py-3 text-gray-600">{{ history.height }}</td>
              <td class="px-3 py-3 text-gray-600">{{ history.bmi }}</td>
              <td class="px-3 py-3">
                <span class="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium"
                  :class="{
                    'bg-green-100 text-green-700': history.nrsClass === 'badge-success',
                    'bg-yellow-100 text-yellow-700': history.nrsClass === 'badge-warning',
                    'bg-red-100 text-red-700': history.nrsClass === 'badge-danger'
                  }">
                  {{ history.nrs }}
                </span>
              </td>
              <td class="px-3 py-3 text-gray-600">{{ history.tdee }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const stats = ref({ bmi: '22.4', tdee: '1,850' })
const historyList = ref([
  { date: '2026-07-15', weight: '68.2', height: '1.75', bmi: '22.4', nrs: '2/7', nrsClass: 'badge-success', tdee: '1,850' },
  { date: '2026-06-15', weight: '69.0', height: '1.75', bmi: '22.6', nrs: '3/7', nrsClass: 'badge-warning', tdee: '1,840' },
  { date: '2026-05-15', weight: '70.1', height: '1.75', bmi: '23.0', nrs: '4/7', nrsClass: 'badge-danger', tdee: '1,820' }
])
</script>