<template>
  <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
    <div class="flex items-center gap-3 mb-4">
      <input 
        type="text" 
        class="flex-1 rounded-lg border border-gray-200 px-4 py-2 text-sm placeholder:text-gray-400 focus:border-[#d4a017] focus:outline-none focus:ring-1 focus:ring-[#d4a017]"
        placeholder="🔍 Search resources..."
        v-model="searchResource"
      />
      <button class="rounded-lg bg-[#1a3a1a] px-4 py-2 text-sm font-medium text-white hover:bg-[#0f2418] transition">
        Upload
      </button>
    </div>

    <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
      <div v-for="(res, i) in filteredResources" :key="i" class="flex items-center gap-4 rounded-lg border border-gray-100 p-4 transition hover:shadow-md">
        <div class="flex h-12 w-12 items-center justify-center rounded-lg text-2xl"
          :style="{ background: res.bg, color: res.color }">
          {{ res.symbol }}
        </div>
        <div class="flex-1">
          <div class="font-semibold text-[#1a3a1a]">{{ res.title }}</div>
          <div class="text-xs text-gray-500">{{ res.type }} · {{ res.meta }}</div>
        </div>
        <button class="rounded-lg border border-gray-200 px-3 py-1 text-xs font-medium text-gray-600 hover:bg-gray-50 transition">
          Download
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'

const resourcesList = [
  { title: 'Diabetes Management Guide', type: 'PDF', meta: '2.4 MB', symbol: '📄', bg: '#e6f4ea', color: '#1a3a1a' },
  { title: 'Meal Planning Template', type: 'Excel', meta: '1.8 MB', symbol: '📊', bg: '#fef7e0', color: '#b06000' },
  { title: 'Nutrition Assessment Form', type: 'Word', meta: '3.1 MB', symbol: '📝', bg: '#f1f3f4', color: '#1a3a1a' },
  { title: 'Patient Education Video', type: 'Video', meta: '45 min', symbol: '🎥', bg: '#e8f0fe', color: '#1a73e8' }
]

const searchResource = ref('')
const filteredResources = computed(() =>
  resourcesList.filter(r => r.title.toLowerCase().includes(searchResource.value.toLowerCase()))
)
</script>