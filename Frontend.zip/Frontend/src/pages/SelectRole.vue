<template>
  <div class="flex min-h-screen items-center justify-center bg-gray-50 px-6 py-12">
    <div class="w-full max-w-3xl">
      <div class="mb-10 text-center">
        <h1 class="text-2xl font-bold text-gray-800">Welcome back</h1>
        <p class="mt-2 text-sm text-gray-500">Choose a portal to continue</p>
      </div>

      <div class="grid grid-cols-1 gap-5 sm:grid-cols-3">
        <button
          v-for="role in roles"
          :key="role.key"
          class="flex flex-col items-center gap-3 rounded-xl border border-gray-200 bg-white p-6 text-center shadow-sm transition hover:-translate-y-0.5 hover:border-[#dce3ec] hover:shadow-md"
          @click="selectRole(role)"
        >
          <div
            class="flex h-14 w-14 items-center justify-center rounded-xl text-2xl"
            :class="role.iconBg"
          >
            {{ role.icon }}
          </div>
          <div>
            <p class="text-sm font-semibold text-gray-800">{{ role.label }}</p>
            <p class="mt-1 text-xs text-gray-500">{{ role.description }}</p>
          </div>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

const roles = [
  {
    key: 'admin',
    label: 'Admin Portal',
    description: 'Manage users & system settings',
    icon: '🛠️',
    iconBg: 'bg-blue-50',
    path: '/admin/dashboard'
  },
  {
    key: 'rnd',
    label: 'RND Portal',
    description: 'Manage clients & screenings',
    icon: '🩺',
    iconBg: 'bg-green-50',
    path: '/rnd/dashboard'
  },
  {
    key: 'client',
    label: 'Client Portal',
    description: 'Track your program & tasks',
    icon: '🧑',
    iconBg: 'bg-yellow-50',
    path: '/client/dashboard'
  }
]

function selectRole(role) {
  router.push(role.path)
}
</script>