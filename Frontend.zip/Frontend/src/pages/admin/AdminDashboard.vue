<template>
  <div class="space-y-6">
    <!-- Stats Grid -->
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500">Total Users</p>
            <p class="text-2xl font-bold text-gray-800">1,284</p>
          </div>
          <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-2xl">
            👥
          </div>
        </div>
        <div class="mt-2 flex items-center text-xs">
          <span class="text-green-600">↑ 12%</span>
          <span class="ml-1 text-gray-500">vs last month</span>
        </div>
      </div>

      <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500">Active RNDs</p>
            <p class="text-2xl font-bold text-gray-800">48</p>
          </div>
          <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-green-50 text-2xl">
            🩺
          </div>
        </div>
        <div class="mt-2 flex items-center text-xs">
          <span class="text-green-600">↑ 4%</span>
          <span class="ml-1 text-gray-500">vs last month</span>
        </div>
      </div>

      <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500">Active Clients</p>
            <p class="text-2xl font-bold text-gray-800">892</p>
          </div>
          <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-yellow-50 text-2xl">
            🧑
          </div>
        </div>
        <div class="mt-2 flex items-center text-xs">
          <span class="text-green-600">↑ 8%</span>
          <span class="ml-1 text-gray-500">vs last month</span>
        </div>
      </div>

      <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm font-medium text-gray-500">Revenue</p>
            <p class="text-2xl font-bold text-gray-800">$24.5k</p>
          </div>
          <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-50 text-2xl">
            💰
          </div>
        </div>
        <div class="mt-2 flex items-center text-xs">
          <span class="text-green-600">↑ 18%</span>
          <span class="ml-1 text-gray-500">vs last month</span>
        </div>
      </div>
    </div>

    <!-- Recent Activity & Quick Actions -->
    <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
      <div class="lg:col-span-2 bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-sm font-semibold text-gray-800">Recent Activity</h3>
          <button class="text-sm font-medium text-[#d4a017] hover:text-[#b88a12]">View All →</button>
        </div>
        <div class="space-y-4">
          <div class="flex items-start gap-3 border-b border-gray-100 pb-3">
            <div class="flex h-8 w-8 items-center justify-center rounded-full bg-green-100 text-sm">✓</div>
            <div>
              <p class="text-sm font-medium text-gray-800">New user registered</p>
              <p class="text-xs text-gray-500">Sarah Johnson · 2 min ago</p>
            </div>
          </div>
          <div class="flex items-start gap-3 border-b border-gray-100 pb-3">
            <div class="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 text-sm">📋</div>
            <div>
              <p class="text-sm font-medium text-gray-800">RND assigned to client</p>
              <p class="text-xs text-gray-500">Ivy Hope Alba → Michael Chen · 15 min ago</p>
            </div>
          </div>
          <div class="flex items-start gap-3">
            <div class="flex h-8 w-8 items-center justify-center rounded-full bg-yellow-100 text-sm">⚠️</div>
            <div>
              <p class="text-sm font-medium text-gray-800">Payment processed</p>
              <p class="text-xs text-gray-500">Invoice #INV-2024-001 · 1 hour ago</p>
            </div>
          </div>
        </div>
      </div>

      <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <h3 class="text-sm font-semibold text-gray-800 mb-4">Quick Actions</h3>
        <div class="space-y-3">
          <button class="flex w-full items-center gap-3 rounded-lg border border-gray-200 px-4 py-3 text-left transition hover:bg-gray-50">
            <span class="text-lg">➕</span>
            <span class="text-sm font-medium text-gray-700">Add New User</span>
          </button>
          <button class="flex w-full items-center gap-3 rounded-lg border border-gray-200 px-4 py-3 text-left transition hover:bg-gray-50">
            <span class="text-lg">📊</span>
            <span class="text-sm font-medium text-gray-700">Generate Report</span>
          </button>
          <button class="flex w-full items-center gap-3 rounded-lg border border-gray-200 px-4 py-3 text-left transition hover:bg-gray-50">
            <span class="text-lg">⚙️</span>
            <span class="text-sm font-medium text-gray-700">System Settings</span>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>