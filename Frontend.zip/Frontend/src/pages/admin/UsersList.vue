<template>
  <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
    <!-- Header -->
    <div class="flex items-center justify-between mb-4">
      <div class="flex items-center gap-3">
        <h3 class="text-sm font-semibold text-gray-800">Manage Users</h3>
        <span class="inline-flex items-center rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-medium text-blue-700">
          {{ users.length }} accounts
        </span>
      </div>
      <div class="flex items-center gap-2">
        <input 
          type="text" 
          class="rounded-lg border border-gray-200 px-3 py-1.5 text-sm placeholder:text-gray-400 focus:border-[#d4a017] focus:outline-none focus:ring-1 focus:ring-[#d4a017]"
          placeholder="Search users..."
          v-model="searchQuery"
        />
        <button class="rounded-lg bg-[#1a3a1a] px-4 py-1.5 text-sm font-medium text-white hover:bg-[#0f2418] transition">
          + Add User
        </button>
      </div>
    </div>

    <!-- Table -->
    <div class="overflow-x-auto">
      <table class="w-full border-collapse text-sm">
        <thead>
          <tr class="border-b border-gray-200">
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Name</th>
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Role</th>
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Email</th>
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Status</th>
            <th class="px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-gray-500">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="account in filteredUsers" :key="account.email" class="border-b border-gray-100 transition hover:bg-gray-50">
            <td class="px-3 py-3 font-medium text-gray-800">{{ account.name }}</td>
            <td class="px-3 py-3">
              <span class="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium" 
                :class="{
                  'bg-green-100 text-green-700': account.role === 'Admin',
                  'bg-blue-100 text-blue-700': account.role === 'RND',
                  'bg-yellow-100 text-yellow-700': account.role === 'Client'
                }">
                {{ account.role }}
              </span>
            </td>
            <td class="px-3 py-3 text-gray-600">{{ account.email }}</td>
            <td class="px-3 py-3">
              <span class="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium" 
                :class="{
                  'bg-green-100 text-green-700': account.status === 'Active',
                  'bg-gray-100 text-gray-700': account.status === 'Inactive'
                }">
                {{ account.status }}
              </span>
            </td>
            <td class="px-3 py-3">
              <div class="flex items-center gap-2">
                <button class="rounded-lg px-2 py-1 text-xs font-medium text-blue-600 hover:bg-blue-50 transition">Edit</button>
                <button class="rounded-lg px-2 py-1 text-xs font-medium text-red-600 hover:bg-red-50 transition">Delete</button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { adminUsersList } from '../../mock/adminMockData'

const users = ref(adminUsersList)
const searchQuery = ref('')

const filteredUsers = computed(() => {
  if (!searchQuery.value) return users.value
  return users.value.filter(user => 
    user.name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
    user.email.toLowerCase().includes(searchQuery.value.toLowerCase())
  )
})
</script>