// One mock "logged in" user per role. In a real app this would come from
// your auth API response instead of being hardcoded here.
export const roleUsers = {
  client: {
    role: 'client',
    roleLabel: 'Client',
    portalLabel: 'Patient Portal',
    name: 'Juan',
    initials: 'JD',
    programWeek: 6,
    rndName: 'RND Ivy Hope Alba',
    nextApptDay: 'Friday'
  },
  rnd: {
    role: 'rnd',
    roleLabel: 'RND',
    portalLabel: 'Dietitian Portal',
    name: 'Ivy Hope Alba',
    initials: 'IA',
    caseload: 18
  },
  admin: {
    role: 'admin',
    roleLabel: 'Admin',
    portalLabel: 'Admin Portal',
    name: 'Miguel Santos',
    initials: 'MS'
  }
}
