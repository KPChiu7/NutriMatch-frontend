export const initialStats = {
  bmi: 23.4,
  weight: 68.2,
  tdee: '1,850',
  protein: 75,
  carbs: 225,
  fat: 55
}

export const initialTasks = [
  {
    id: 1,
    title: 'Log all meals using the FNRI exchange guide',
    freq: 'Daily — ongoing',
    completed: true
  },
  {
    id: 2,
    title: 'Hydration — 8 glasses of water daily',
    freq: 'Daily',
    completed: true
  },
  {
    id: 3,
    title: 'Check and record fasting blood sugar',
    freq: 'Daily — before breakfast',
    completed: false
  },
  {
    id: 4,
    title: 'Light walk — 30 minutes, 3x per week',
    freq: 'Mon / Wed / Fri',
    completed: false
  },
  {
    id: 5,
    title: 'Read: Managing Carb Cravings (resource article)',
    freq: 'One time',
    completed: false
  }
]

export const screeningHistory = [
  {
    date: 'Jun 15, 2026',
    weight: '68.2 kg',
    height: '171 cm',
    bmi: '23.4',
    nrs: '2',
    nrsClass: 'badge-warning',
    tdee: '1,804 kcal'
  },
  {
    date: 'May 20, 2026',
    weight: '69.0 kg',
    height: '171 cm',
    bmi: '23.7',
    nrs: '2',
    nrsClass: 'badge-warning',
    tdee: '1,820 kcal'
  },
  {
    date: 'Apr 18, 2026',
    weight: '70.5 kg',
    height: '171 cm',
    bmi: '24.2',
    nrs: '1',
    nrsClass: 'badge-neutral',
    tdee: '1,850 kcal'
  }
]

export const initialMealLogs = [
  {
    slot: 'Breakfast',
    time: '7:00 AM',
    details: 'Brown rice, fried egg, kangkong',
    logged: true
  },
  {
    slot: 'AM Snack',
    time: '10:00 AM',
    details: 'Banana Saba, low-fat milk',
    logged: true
  }
]

export const resourcesList = [
  {
    title: 'FNRI Food Exchange List Guide',
    type: 'PDF',
    meta: '2 days ago',
    bg: 'rgba(192,57,43,.1)',
    color: '#c0392b',
    symbol: '📄'
  },
  {
    title: 'Reading Nutrition Labels',
    type: 'Video',
    meta: '6 min',
    bg: 'rgba(47,111,168,.1)',
    color: '#2f6fa8',
    symbol: '▶️'
  },
  {
    title: 'Managing Carb Cravings',
    type: 'Article',
    meta: '4 min read',
    bg: '#f2f7f2',
    color: '#1a3a1a',
    symbol: '📖'
  }
]

export const remindersList = [
  {
    title: 'Meal Logging',
    time: 'Daily at 7:00 AM, 12:00 PM, 7:00 PM',
    status: 'Active',
    badgeClass: 'badge-success'
  },
  {
    title: 'Fasting Blood Sugar Check',
    time: 'Daily at 6:30 AM',
    status: 'Active',
    badgeClass: 'badge-success'
  },
  {
    title: 'Appointment Reminder — Jul 4',
    time: 'Jul 3 at 5:00 PM',
    status: 'Upcoming',
    badgeClass: 'badge-info'
  }
]

export const initialInvoices = [
  {
    id: 'INV-0231',
    date: 'Jul 4, 2026',
    amount: '₱800.00',
    status: 'Unpaid',
    statusClass: 'badge-warning',
    paid: false
  },
  {
    id: 'INV-0214',
    date: 'Jun 15, 2026',
    amount: '₱800.00',
    status: 'Paid',
    statusClass: 'badge-success',
    paid: true
  },
  {
    id: 'INV-0198',
    date: 'May 20, 2026',
    amount: '₱800.00',
    status: 'Paid',
    statusClass: 'badge-success',
    paid: true
  }
]
