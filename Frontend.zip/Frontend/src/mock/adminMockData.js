export const adminUsersList = [
  {
    name: 'Juan Dela Cruz',
    role: 'Client',
    email: 'juan.delacruz@example.com',
    status: 'Active',
    badgeClass: 'badge-success'
  },
  {
    name: 'Maria Santos',
    role: 'Client',
    email: 'maria.santos@example.com',
    status: 'Active',
    badgeClass: 'badge-success'
  },
  {
    name: 'RND Ivy Hope Alba',
    role: 'RND',
    email: 'ivy.alba@nutrimatch.ph',
    status: 'Active',
    badgeClass: 'badge-info'
  },
  {
    name: 'Miguel Santos',
    role: 'Admin',
    email: 'miguel.santos@nutrimatch.ph',
    status: 'Active',
    badgeClass: 'badge-neutral'
  }
]
