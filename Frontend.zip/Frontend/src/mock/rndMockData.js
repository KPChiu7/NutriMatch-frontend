export const rndClientsList = [
  {
    name: 'Juan Dela Cruz',
    program: 'Diabetes Management',
    week: 6,
    status: 'On Track',
    badgeClass: 'badge-success'
  },
  {
    name: 'Maria Santos',
    program: 'Weight Management',
    week: 3,
    status: 'At Risk',
    badgeClass: 'badge-warning'
  },
  {
    name: 'Pedro Reyes',
    program: 'Renal Nutrition',
    week: 10,
    status: 'On Track',
    badgeClass: 'badge-success'
  },
  {
    name: 'Angela Cruz',
    program: 'Diabetes Management',
    week: 1,
    status: 'New',
    badgeClass: 'badge-info'
  }
]
