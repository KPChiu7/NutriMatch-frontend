export const navigationByRole = {
  client: [
    { path: '/', label: 'Overview', symbol: '📊' },
    { path: '/screening', label: 'Health Screening', symbol: '🛡️' },
    { path: '/tasks', label: 'My Tasks', symbol: '☑️' },
    { path: '/logging', label: 'Log Progress', symbol: '➕' },
    { path: '/summaries', label: 'Summaries', symbol: '📄' },
    { path: '/resources', label: 'Resources', symbol: '📚' },
    { path: '/reminders', label: 'Reminders', symbol: '⏰' },
    { path: '/billing', label: 'Billing', symbol: '💳' }
  ],
  rnd: [
    { path: '/rnd/clients', label: 'My Clients', symbol: '🧑‍🤝‍🧑' },
    { path: '/summaries', label: 'Summaries', symbol: '📄' },
    { path: '/resources', label: 'Resources', symbol: '📚' }
  ],
  admin: [
    { path: '/admin/users', label: 'Manage Users', symbol: '🗂️' },
    { path: '/billing', label: 'Billing Overview', symbol: '💳' },
    { path: '/resources', label: 'Resources', symbol: '📚' }
  ]
}

export const defaultRouteByRole = {
  client: '/',
  rnd: '/rnd/clients',
  admin: '/admin/users'
}
