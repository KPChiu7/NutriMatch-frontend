<template>
  <aside 
    class="fixed top-0 h-screen w-[260px] bg-[#0b1a12] text-white p-5 flex flex-col flex-shrink-0 border-r border-white/5 shadow-2xl z-90 transition-left duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] md:sticky md:left-0"
    :class="{ 'left-0': isOpen, '-left-[270px]': !isOpen }"
  >
    <!-- Header -->
    <div class="flex items-center justify-between px-2.5 pb-5 border-b border-white/10">
      <div class="text-xl font-extrabold tracking-tight">
        <span class="text-white">Nutri</span><span class="text-[#d4a017]">Match</span>
      </div>
      <button 
        class="flex items-center justify-center w-[30px] h-[30px] rounded-md bg-white/10 border-none text-white cursor-pointer md:hidden"
        @click="$emit('close')"
      >
        ❌
      </button>
    </div>

    <!-- Scrollable Content -->
    <div class="flex-1 overflow-y-auto pt-4 flex flex-col gap-6">
      <!-- MAIN NAVIGATION SECTION -->
      <div>
        <div class="text-[0.68rem] font-bold tracking-[1.2px] text-white/40 mb-2 pl-3">
          MENU
        </div>
        <nav class="flex flex-col gap-1">
          <router-link 
            v-for="nav in navItems" 
            :key="nav.path" 
            :to="nav.path"
            class="flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-[0.88rem] font-medium text-[#a3b8a3] no-underline transition-all duration-200 hover:bg-white/10 hover:text-white"
            active-class="!bg-[#d4a017]/15 !text-[#ffd769] !font-semibold relative before:content-[''] before:absolute before:left-0 before:top-[20%] before:h-[60%] before:w-1 before:bg-[#d4a017] before:rounded-r before:rounded-l-none"
            @click="$emit('close')"
          >
            <span class="text-[1.05rem]">{{ nav.symbol }}</span>
            <span>{{ nav.label }}</span>
          </router-link>
        </nav>
      </div>

      <!-- ACCOUNT SECTION -->
      <div>
        <div class="text-[0.68rem] font-bold tracking-[1.2px] text-white/40 mb-2 pl-3">
          ACCOUNT
        </div>
        <nav class="flex flex-col gap-1">
          <router-link 
            to="/settings" 
            class="flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-[0.88rem] font-medium text-[#a3b8a3] no-underline transition-all duration-200 hover:bg-white/10 hover:text-white"
            active-class="!bg-[#d4a017]/15 !text-[#ffd769] !font-semibold relative before:content-[''] before:absolute before:left-0 before:top-[20%] before:h-[60%] before:w-1 before:bg-[#d4a017] before:rounded-r before:rounded-l-none"
            @click="$emit('close')"
          >
            <span class="text-[1.05rem]">⚙️</span>
            <span>Settings</span>
          </router-link>
          <button 
            class="flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-[0.88rem] font-medium text-[#a3b8a3] no-underline transition-all duration-200 hover:bg-white/10 hover:text-white w-full text-left border-none bg-transparent cursor-pointer"
            @click="$emit('logout')"
          >
            <span class="text-[1.05rem]">🚪</span>
            <span>Log Out</span>
          </button>
        </nav>
      </div>
    </div>

    <!-- Footer User Card -->
    <div class="pt-4 border-t border-white/10">
      <div class="flex items-center gap-3 p-2 rounded-lg bg-white/5">
        <div class="flex items-center justify-center w-9 h-9 rounded-lg bg-[#d4a017] text-[#0b1a12] font-bold text-[0.85rem]">
          {{ user.initials }}
        </div>
        <div>
          <div class="text-[0.85rem] font-semibold text-white">{{ user.name }}</div>
          <div class="text-[0.72rem] text-[#8aa38a]">
            {{ user.roleLabel }}<span v-if="user.programWeek"> · Wk {{ user.programWeek }}</span>
          </div>
        </div>
      </div>
    </div>
  </aside>
</template>

<script setup>
import { computed } from 'vue'
import { navigationByRole } from '../config/navigation'

const props = defineProps({
  isOpen: { type: Boolean, default: false },
  user: { type: Object, required: true }
})

const emit = defineEmits(['close', 'logout'])

const navItems = computed(() => navigationByRole[props.user.role] || [])
</script>