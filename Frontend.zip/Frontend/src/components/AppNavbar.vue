<template>
  <header class="sticky top-0 z-80 flex h-[72px] items-center justify-between border-b border-[#e9edf2] bg-white px-6 shadow-sm transition-shadow md:px-8">
    <!-- Left side -->
    <div class="flex items-center gap-4 md:gap-5">
      <button
        class="flex h-5 w-6 flex-col justify-between border-none bg-transparent p-0 md:hidden"
        @click="$emit('toggle-sidebar')"
        aria-label="Toggle sidebar"
      >
        <span class="block h-[2.5px] w-full rounded-sm bg-[#1e2b3c]"></span>
        <span class="block h-[2.5px] w-full rounded-sm bg-[#1e2b3c]"></span>
        <span class="block h-[2.5px] w-full rounded-sm bg-[#1e2b3c]"></span>
      </button>

      <div class="whitespace-nowrap rounded-full border border-[#dce3ec] bg-[#f0f4fa] px-4 py-1.5 text-sm font-medium text-[#1a2b3c]">
        {{ user.portalLabel }}<span v-if="user.programWeek"> · Week {{ user.programWeek }}</span>
      </div>
    </div>

    <!-- Right side -->
    <div class="flex items-center gap-1.5 sm:gap-2">
      <!-- Notification bell -->
      <button
        class="relative flex h-9 w-9 items-center justify-center rounded-full border-none bg-transparent text-[#3d4e62] transition hover:bg-[#f0f5fe] hover:text-[#1a2b3c] sm:h-10 sm:w-10"
        title="Notifications"
        aria-label="Notifications"
      >
        <svg class="h-5 w-5 transition-transform hover:scale-105" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
          <path d="M13.73 21a2 2 0 0 1-3.46 0" />
        </svg>
        <span class="absolute right-1.5 top-1.5 h-2 w-2 rounded-full border-2 border-white bg-[#d43f34] shadow-[0_0_0_1px_rgba(212,63,52,0.15)] sm:right-2 sm:top-2 sm:h-2.5 sm:w-2.5"></span>
      </button>

      <!-- Messages -->
      <button
        class="flex h-9 w-9 items-center justify-center rounded-full border-none bg-transparent text-[#3d4e62] transition hover:bg-[#f0f5fe] hover:text-[#1a2b3c] sm:h-10 sm:w-10"
        title="Messages"
        aria-label="Messages"
      >
        <svg class="h-5 w-5 transition-transform hover:scale-105" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
        </svg>
      </button>

      <!-- User dropdown -->
      <div
        class="relative cursor-pointer outline-none"
        @click="toggleDropdown"
        @blur="closeDropdown"
        tabindex="0"
      >
        <div class="flex items-center gap-1.5 rounded-full border border-[#e9edf2] bg-white py-0.5 pl-1.5 pr-3 transition hover:border-[#c8d0dc] hover:bg-[#fafcff] sm:gap-2.5 sm:pl-2 sm:pr-4">
          <div class="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-[#1e2b3c] text-sm font-semibold text-white sm:h-9 sm:w-9">
            {{ user.initials }}
          </div>
          <div class="hidden flex-col leading-tight md:flex">
            <span class="text-sm font-semibold text-[#1e2b3c]">{{ user.name }}</span>
            <span class="text-xs font-medium text-[#6b7a8b]">{{ user.roleLabel }}</span>
          </div>
          <svg
            class="ml-0.5 text-[#6b7a8b] transition-transform duration-200 sm:ml-1"
            :class="{ 'rotate-180': isDropdownOpen }"
            viewBox="0 0 24 24"
            width="16"
            height="16"
            fill="none"
            stroke="currentColor"
            stroke-width="2.5"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <polyline points="6 9 12 15 18 9" />
          </svg>
        </div>

        <!-- Dropdown menu -->
        <div
          v-if="isDropdownOpen"
          class="absolute right-0 top-full mt-2 min-w-[170px] animate-[dropdownFade_0.18s_ease] rounded-xl border border-[#e9edf2] bg-white py-1.5 shadow-xl sm:min-w-[200px]"
        >
          <button
            class="flex w-full items-center gap-3 border-none bg-transparent px-4 py-2.5 text-left text-sm font-medium text-[#1e2b3c] transition hover:bg-[#f5f9ff] sm:px-5"
            @click="handleProfile"
          >
            <svg class="h-4 w-4 flex-shrink-0 text-[#5b6d7e]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
              <circle cx="12" cy="7" r="4" />
            </svg>
            Profile
          </button>
          <button
            class="flex w-full items-center gap-3 border-none bg-transparent px-4 py-2.5 text-left text-sm font-medium text-[#1e2b3c] transition hover:bg-[#f5f9ff] sm:px-5"
            @click="handleSettings"
          >
            <svg class="h-4 w-4 flex-shrink-0 text-[#5b6d7e]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="3" />
              <path d="M12 1v4M12 19v4M4.22 4.22l2.83 2.83M16.95 16.95l2.83 2.83M1 12h4M19 12h4M4.22 19.78l2.83-2.83M16.95 7.05l2.83-2.83" />
            </svg>
            Settings
          </button>
          <div class="mx-3 my-1.5 h-px bg-[#e9edf2]"></div>
          <button
            class="flex w-full items-center gap-3 border-none bg-transparent px-4 py-2.5 text-left text-sm font-medium text-[#c0392b] transition hover:bg-[#fdeaea] sm:px-5"
            @click="handleLogout"
          >
            <svg class="h-4 w-4 flex-shrink-0 text-[#c0392b]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              <polyline points="16 17 21 12 16 7" />
              <line x1="21" y1="12" x2="9" y2="12" />
            </svg>
            Log Out
          </button>
        </div>
      </div>
    </div>
  </header>
</template>

<script setup>
import { ref } from 'vue'

defineProps({
  user: { type: Object, required: true }
})

const emit = defineEmits(['toggle-sidebar', 'logout'])

const isDropdownOpen = ref(false)

function toggleDropdown(e) {
  e.stopPropagation()
  isDropdownOpen.value = !isDropdownOpen.value
}

function closeDropdown() {
  isDropdownOpen.value = false
}

function handleProfile() {
  isDropdownOpen.value = false
  console.log('Navigate to profile')
}

function handleSettings() {
  isDropdownOpen.value = false
  console.log('Navigate to settings')
}

function handleLogout() {
  isDropdownOpen.value = false
  emit('logout')
}
</script>

<style>
@keyframes dropdownFade {
  from {
    opacity: 0;
    transform: translateY(-6px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>