<template>
  <div class="bg-white rounded-xl border border-gray-200 p-4 shadow-sm hover:shadow-md transition-shadow">
    <!-- Header -->
    <div class="flex items-center justify-between mb-4">
      <h3 class="text-sm font-semibold text-gray-800">Weight Progress (kg)</h3>
      <span class="inline-flex items-center rounded-full bg-green-50 px-2.5 py-0.5 text-xs font-medium text-green-700">
        ↓ 4.1 kg total
      </span>
    </div>

    <!-- Chart Container -->
    <div class="w-full">
      <svg viewBox="0 0 460 120" width="100%" class="block">
        <defs>
          <linearGradient id="wGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#1a3a1a" stop-opacity=".18"/>
            <stop offset="100%" stop-color="#1a3a1a" stop-opacity="0"/>
          </linearGradient>
        </defs>
        <g transform="translate(20,10)">
          <!-- Area under the line -->
          <path 
            d="M0,80 L80,72 L160,60 L240,48 L320,36 L400,24 L400,95 L0,95Z" 
            fill="url(#wGrad)"
          />
          
          <!-- Main line -->
          <path 
            d="M0,80 L80,72 L160,60 L240,48 L320,36 L400,24" 
            stroke="#1a3a1a" 
            stroke-width="2.5" 
            fill="none" 
            stroke-linecap="round" 
            stroke-linejoin="round"
          />
          
          <!-- Data points -->
          <circle cx="0" cy="80" r="4" fill="#1a3a1a"/>
          <circle cx="80" cy="72" r="4" fill="#1a3a1a"/>
          <circle cx="160" cy="60" r="4" fill="#1a3a1a"/>
          <circle cx="240" cy="48" r="4" fill="#1a3a1a"/>
          <circle cx="320" cy="36" r="4" fill="#1a3a1a"/>
          
          <!-- Current month point (highlighted) -->
          <circle cx="400" cy="24" r="5" fill="#D4A017" stroke="#fff" stroke-width="2"/>
          
          <!-- Month labels -->
          <text x="0" y="110" font-size="9" fill="#8aaa8a">Feb</text>
          <text x="76" y="110" font-size="9" fill="#8aaa8a">Mar</text>
          <text x="152" y="110" font-size="9" fill="#8aaa8a">Apr</text>
          <text x="228" y="110" font-size="9" fill="#8aaa8a">May</text>
          <text x="308" y="110" font-size="9" fill="#8aaa8a">Jun</text>
          <text x="390" y="110" font-size="9" fill="#D4A017" font-weight="700">Jul</text>
          
          <!-- Weight labels -->
          <text x="-5" y="73" font-size="9" fill="#1a3a1a">72.3</text>
          <text x="385" y="15" font-size="9" fill="#D4A017" font-weight="700">{{ weight || 68.2 }}</text>
        </g>
      </svg>
    </div>
  </div>
</template>

<script setup>
defineProps({
  weight: Number
})
</script>