import { computed } from 'vue'

// Central place for per-role display data.
// Swap this for a real API/auth call whenever you're ready —
// every layout just calls useRoleUser(role) and gets the right shape back.
const ROLE_USERS = {
  admin: {
    name: 'Admin User',
    initials: 'AU',
    roleLabel: 'Administrator',
    portalLabel: 'Admin Portal',
    programWeek: null,
    role: 'admin'
  },
  client: {
    name: 'John Doe',
    initials: 'JD',
    roleLabel: 'Client',
    portalLabel: 'Client Portal',
    programWeek: 4,
    role: 'client'
  },
  rnd: {
    name: 'Ivy Hope Alba',
    initials: 'IA',
    roleLabel: 'RND',
    portalLabel: 'RND Portal',
    programWeek: null,
    role: 'rnd'
  }
}

export function useRoleUser(role) {
  const user = computed(() => ROLE_USERS[role] ?? ROLE_USERS.client)
  return { user }
}