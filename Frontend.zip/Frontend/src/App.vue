<template>
  <!--
    Each role route (/admin, /client, /rnd) already gets its sidebar + navbar
    from AppLayout via the router (see src/router/index.js). No extra
    wrapper layout is needed here - just render the matched route.
  -->
  <router-view />
</template>

<script setup>
</script>