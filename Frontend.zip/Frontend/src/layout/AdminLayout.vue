<template>
  <div class="flex min-h-screen bg-gray-50">
    <AppSidebar 
      :isOpen="sidebarOpen" 
      @close="sidebarOpen = false" 
      :user="user" 
      @logout="handleLogout"
    />
    <div class="flex-1 flex flex-col min-h-screen">
      <AppNavbar 
        @toggle-sidebar="sidebarOpen = !sidebarOpen" 
        :user="user" 
        @logout="handleLogout"
      />
      <main class="flex-1 p-6">
        <router-view />
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import AppNavbar from '../components/AppNavbar.vue'
import AppSidebar from '../components/AppSidebar.vue'

const router = useRouter()
const sidebarOpen = ref(false)

const user = ref({
  name: 'Admin User',
  initials: 'AU',
  roleLabel: 'Administrator',
  portalLabel: 'Admin Portal',
  programWeek: null,
  role: 'admin'
})

const handleLogout = () => {
  router.push('/select-role')
}
</script>