<template>
  <div class="flex min-h-screen bg-gray-50">
    <AppSidebar :isOpen="sidebarOpen" @close="sidebarOpen = false" :user="user" />
    <div class="flex-1">
      <AppNavbar @toggle-sidebar="sidebarOpen = !sidebarOpen" :user="user" @logout="handleLogout" />
      <main class="p-6">
        <router-view />
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import AppNavbar from '../components/AppNavbar.vue'
import AppSidebar from '../components/AppSidebar.vue'

const router = useRouter()
const sidebarOpen = ref(false)
const user = ref({
  name: 'Ivy Hope Alba',
  initials: 'IA',
  roleLabel: 'RND',
  portalLabel: 'RND Portal',
  programWeek: null,
  role: 'rnd'
})

const handleLogout = () => {
  router.push('/select-role')
}
</script>