<template>
  <div class="flex min-h-screen bg-gray-50">
    <AppSidebar :isOpen="sidebarOpen" @close="sidebarOpen = false" :user="user" @logout="handleLogout" />
    <div class="flex-1 flex flex-col min-h-screen">
      <AppNavbar @toggle-sidebar="sidebarOpen = !sidebarOpen" :user="user" @logout="handleLogout" />
      <main class="flex-1 p-6">
        <router-view />
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import AppNavbar from '../components/AppNavbar.vue'
import AppSidebar from '../components/AppSidebar.vue'
import { useRoleUser } from '../composables/useRoleUser'

const props = defineProps({
  role: { type: String, required: true } // 'admin' | 'client' | 'rnd'
})

const router = useRouter()
const sidebarOpen = ref(false)
const { user } = useRoleUser(props.role)

const handleLogout = () => {
  router.push('/select-role')
}
</script>