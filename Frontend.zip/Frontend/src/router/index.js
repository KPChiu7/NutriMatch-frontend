import { createRouter, createWebHistory } from 'vue-router'

// Admin
import AdminDashboard from '../pages/admin/AdminDashboard.vue'
import UsersList from '../pages/admin/UsersList.vue'

// RND
import RNDDashboard from '../pages/rnd/RNDDashboard.vue'
import ClientsList from '../pages/rnd/ClientsList.vue'
import Billing from '../pages/rnd/billing.vue' // Make sure the file on disk is exactly named billing.vue
import LoggingRND from '../pages/rnd/logging.vue'
import RemindersRND from '../pages/rnd/reminders.vue'
import ResourcesRND from '../pages/rnd/resources.vue'
import ScreeningRND from '../pages/rnd/screening.vue'
import SummariesRND from '../pages/rnd/summaries.vue'
import TasksRND from '../pages/rnd/tasks.vue'

// Client
import ClientDashboard from '../pages/client/ClientDashboard.vue'
import LoggingClient from '../pages/client/logging.vue'
import RemindersClient from '../pages/client/reminders.vue'
import ResourcesClient from '../pages/client/resources.vue'
import ScreeningClient from '../pages/client/screening.vue'
import SummariesClient from '../pages/client/summaries.vue'
import TasksClient from '../pages/client/tasks.vue'

// Shared
import SelectRole from '../pages/SelectRole.vue'

// One layout, driven by a 'role' prop, instead of three near-identical
// AdminLayout/ClientLayout/RNDLayout files. See src/layout/AppLayout.vue
// and src/composables/useRoleUser.js.
const AppLayout = () => import('../layout/AppLayout.vue')

const routes = [
  { path: '/', redirect: '/select-role' },
  { path: '/select-role', component: SelectRole },

  // Redirect unmatched /screening to select role
  { path: '/screening', redirect: '/select-role' },

  // Admin routes
  {
    path: '/admin',
    component: AppLayout,
    props: { role: 'admin' },
    children: [
      { path: 'dashboard', component: AdminDashboard },
      { path: 'users', component: UsersList }
    ]
  },

  // RND routes
  {
    path: '/rnd',
    component: AppLayout,
    props: { role: 'rnd' },
    children: [
      { path: 'dashboard', component: RNDDashboard },
      { path: 'clients', component: ClientsList },
      { path: 'billing', component: Billing },
      { path: 'logging', component: LoggingRND },
      { path: 'reminders', component: RemindersRND },
      { path: 'resources', component: ResourcesRND },
      { path: 'screening', component: ScreeningRND },
      { path: 'summaries', component: SummariesRND },
      { path: 'tasks', component: TasksRND }
    ]
  },

  // Client routes
  {
    path: '/client',
    component: AppLayout,
    props: { role: 'client' },
    children: [
      { path: 'dashboard', component: ClientDashboard },
      { path: 'logging', component: LoggingClient },
      { path: 'reminders', component: RemindersClient },
      { path: 'resources', component: ResourcesClient },
      { path: 'screening', component: ScreeningClient },
      { path: 'summaries', component: SummariesClient },
      { path: 'tasks', component: TasksClient }
    ]
  },

  // Catch-all 404 route (MUST be last)
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    redirect: '/select-role' // Or import a NotFound.vue page here
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router